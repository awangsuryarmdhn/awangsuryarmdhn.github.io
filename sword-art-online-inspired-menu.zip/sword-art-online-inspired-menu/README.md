# Sword Art Online Inspired Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/eeieeipoo/pen/mJyvYK](https://codepen.io/eeieeipoo/pen/mJyvYK).

Just a quick Sword Art Online style menu, no javascript.