<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* 
 *  ======================================= 
 *  Author     : Slamet Nurhadi
 *  License    : NO License
 *  Email      : slametnhd@gmail.com
 *   
 *  
 *  
 *  ======================================= 
 */  
  require_once APPPATH."/third_party/EasyRdf.php"; 
  
class Rdf 
{ 
  

} 