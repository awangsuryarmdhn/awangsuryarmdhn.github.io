RDF by Tony Wijaya
==================

Codeigniter Framework for RDF (Bootstrap Template)

Codeigniter 2.2 templating for easyRDF

<tt>localhost/semantic_web_011100862/index.php/basic</tt> (for basic httpGet ) 

<tt>localhost/semantic_web_011100862/index.php/basic/sparql</tt> (for query SPARQL ) 

<tt>localhost/semantic_web_011100862/index.php/basic/foafinfo</tt> (foafinfo) 

<tt>localhost/semantic_web_011100862/index.php/basic/foafmaker</tt> (foafmaker) 

<tt>localhost/semantic_web_011100862/index.php/basic/converter</tt> (converter)

 
 

 
 ![Image of Yaktocat](https://ndesostyle.files.wordpress.com/2014/10/easyrdf.png)
 
 
 
 
  ![Image of Yaktocat](http://www.disewain.com/public/logo/rumah.png)
 
 

 

 
